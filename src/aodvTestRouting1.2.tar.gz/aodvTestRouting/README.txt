This code is developped by
the networking lab of the Faculty of Sciences of the University of Mons (Belgium)

contact: mathieu.michel@umons.ac.be 


This implementation is based
on the source code provided by the following contributor


 * Module:   AODV Routing Protocol for Castalia Simulator
 * Author:   Xu Zongque 
 * Version:  0.1
 * Contact:  Paolo Roberto Grassi <grassi@elet.polimi.it>
 * Project:  Multi Sensor and Actuator Networks
 * Owner:    Politecnico di Milano (MI) - ITALY
